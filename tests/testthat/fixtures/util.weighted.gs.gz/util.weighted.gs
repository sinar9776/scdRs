TRAIT	GENESET
T1	Gene_b:1.5,Gene_a:2,Gene_b:0.25,Gene_c:-1e-3
T2	Gene_c,Gene_a
