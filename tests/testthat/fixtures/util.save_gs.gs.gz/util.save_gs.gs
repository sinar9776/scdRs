TRAIT	GENESET
T1	Gene_b:0.25,Gene_a:2.0,Gene_c:-0.001
T2	Gene_c:1.0,Gene_a:1.0
